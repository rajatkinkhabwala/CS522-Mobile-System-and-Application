package com.example.rk;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.rk.messageforwardingapp.R;

public class RecieveMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recieve_message);
        Intent intent=getIntent();
        String messageText=intent.getStringExtra("MESSAGE");
        TextView messageView=(TextView) findViewById(R.id.message);
        messageView.setText(messageText);
    }
}
