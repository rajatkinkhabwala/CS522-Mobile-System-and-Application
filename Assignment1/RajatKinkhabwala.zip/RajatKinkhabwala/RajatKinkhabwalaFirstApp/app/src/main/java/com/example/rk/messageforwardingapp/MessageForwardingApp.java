package com.example.rk.messageforwardingapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.example.rk.RecieveMessageActivity;

public class MessageForwardingApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_forwarding_app);
    }
    public void SendMessage(View view){
        EditText messageView=(EditText)findViewById(R.id.msg);
        String messageText=messageView.getText().toString();
        Intent intent=new Intent(this, RecieveMessageActivity.class);
        intent.putExtra("MESSAGE", messageText);
        startActivity(intent);
    }
}
