package edu.stevens.cs522.bookstore.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;

				public class AddBookActivity extends AppCompatActivity {

					// Use this as the key to return the book details as a Parcelable extra in the result intent.
					public static final String BOOK_RESULT_KEY = "book_result";

					@Override
					public void onCreate(Bundle savedInstanceState) {
						super.onCreate(savedInstanceState);
						setContentView(R.layout.add_book);

						}

					@Override
					public boolean onCreateOptionsMenu(Menu menu) {
						super.onCreateOptionsMenu(menu);
						// TODO provide ADD and CANCEL options
						MenuInflater inflater = getMenuInflater();
						inflater.inflate(R.menu.add_book_menu, menu);
						return super.onCreateOptionsMenu(menu);
					}

					@Override
					public boolean onOptionsItemSelected(MenuItem item) {
						super.onOptionsItemSelected(item);
						// TODO
						switch(item.getItemId()) {
							case R.id.add:
								Book resultBook = addBook();
								Intent result = new Intent();
								result.putExtra(BOOK_RESULT_KEY, resultBook);
								setResult(RESULT_OK, result);
								finish();

								break;
							case R.id.cancel:
								Intent cancelIntent=new Intent(this,MainActivity.class);
								startActivity(cancelIntent);
							default:
								return super.onOptionsItemSelected(item);
						}

						// ADD: return the book details to the BookStore activity

						// CANCEL: cancel the request
						return false;
					}

					public Book addBook(){

						// TODO Just build a Book object with the search criteria and return that.

						EditText editTitle = (EditText) findViewById(R.id.search_title);
						String title = editTitle.getText().toString();
						EditText editAuthor = (EditText) findViewById(R.id.search_author);
						String authorString=editAuthor.getText().toString();
						String[] authors = authorString.split(",");
						Author[] authorsArray = new Author[authors.length];
						for (int i = 0; i < authors.length; i++) {
							authorsArray[i] = new Author(authors[i].split(" "));
						}

						EditText editIsbn = (EditText) findViewById(R.id.search_isbn);
						String isbn = editIsbn.getText().toString();

						Log.e(title, authorsArray[0].lastName);
						Log.e("isbn:", isbn);

						Book newBook = new Book(100, title, authorsArray, isbn, "10");
						Log.e("author",authorsArray.toString());
						return newBook;


					}
				}