package edu.stevens.cs522.bookstore.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class Book implements Parcelable{
	
	// TODO Modify this to implement the Parcelable interface.

	public int id;
	
	public String title;
	
	public Author[] authors ;
	
	public String isbn;
	
	public String price;

	public Book(int id, String title, Author[] authors, String isbn, String price) {
		this.id = id;
		this.title = title;
		this.authors = authors;
		this.isbn = isbn;
		this.price = price;
	}

	@Override
	public int describeContents() {
		return hashCode();
	}

	@Override
	public void writeToParcel(Parcel out, int flags) {
		out.writeInt(id);
		out.writeString(title);
		out.writeTypedArray(authors, flags);
		out.writeString(isbn);
		out.writeString(price);
	}

	public Book(Parcel in) {

		this.id = in.readInt();
		this.title = in.readString();
		this.authors=in.createTypedArray(Author.CREATOR);
		this.isbn = in.readString();
		this.price = in.readString();



	}
	@Override
	public String toString() {
		return "Book{" +
				"price='" + price + '\'' +
				", title='" + title + '\'' +
				'}';
	}

	public String getFirstAuthor() {
		if (authors != null && authors.length > 0) {
			return authors[0].toString();
		} else {
			return "";
		}
	}
	public static final Parcelable.Creator<Book> CREATOR = new Parcelable.Creator<Book>() {
		public Book createFromParcel(Parcel in) {
			return new Book(in);
		}

		public Book[] newArray(int size) {
			return new Book[size];
		}
	};

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Author[] getAuthors() {
		return authors;
	}

	public void setAuthors(Author[] authors) {
		this.authors = authors;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public static Creator<Book> getCREATOR() {
		return CREATOR;
	}
}