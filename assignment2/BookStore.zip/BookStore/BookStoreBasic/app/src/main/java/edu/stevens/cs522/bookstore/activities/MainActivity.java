package edu.stevens.cs522.bookstore.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.entities.Book;
import edu.stevens.cs522.bookstore.util.BooksAdapter;

public class MainActivity extends AppCompatActivity {

	// Use this when logging errors and warnings.
	private static final String TAG = MainActivity.class.getCanonicalName();

	// These are request codes for subactivity request calls
	static final private int ADD_REQUEST = 1;

	static final private int CHECKOUT_REQUEST = ADD_REQUEST + 1;

	// There is a reason this must be an ArrayList instead of a List.
				private ArrayList<Book> shoppingCart;
				BooksAdapter booksAdapter;
				private ListView listView;
				static final private String cart = "list";
				public static final String BOOK_DETAILS = "Book_Details";

				@Override
				public void onCreate(Bundle savedInstanceState) {
					super.onCreate(savedInstanceState);

					// TODO check if there is saved UI state, and if so, restore it (i.e. the cart contents)
					if (savedInstanceState != null)
						shoppingCart = savedInstanceState.getParcelableArrayList("list");

					// TODO Set the layout (use cart.xml layout)
					setContentView(R.layout.cart);

					// TODO use an array adapter to display the cart contents.
					shoppingCart=new ArrayList<Book>();
					booksAdapter = new BooksAdapter(this, shoppingCart);
					listView = (ListView) findViewById(android.R.id.list);
					listView.setAdapter(booksAdapter);


					listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
					listView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
						@Override
						public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
							mode.setTitle(listView.getCheckedItemCount() + " Selected Items");
						}

						@Override
						public boolean onCreateActionMode(ActionMode mode, Menu menu) {
							mode.getMenuInflater().inflate(R.menu.menu_delete, menu);
							return true;
						}

						@Override
						public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
							return false;
						}

						@Override
						public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
							if (item.getItemId() == R.id.menu_delete) {
								onClickDeleteButton();
								mode.finish();
								return true;
							}
							return false;
						}
						@Override
						public void onDestroyActionMode(ActionMode mode) {
						}
					});

					listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
							Intent intent = new Intent(getApplicationContext(), ViewBookActivity.class);
							Book bookSelected = shoppingCart.get(position);
							intent.putExtra(BOOK_DETAILS, bookSelected);
							startActivity(intent);
						}
					});

				}
				@Override
				public boolean onCreateOptionsMenu(Menu menu) {
					super.onCreateOptionsMenu(menu);
					MenuInflater inflater = getMenuInflater();
					inflater.inflate(R.menu.bookstore_menu, menu);
					return super.onCreateOptionsMenu(menu);
				}

				@Override
				public boolean onOptionsItemSelected(MenuItem item) {
					super.onOptionsItemSelected(item);
					Intent addIntent;
					if (item.getItemId() == R.id.add) {
						addIntent = new Intent(this, AddBookActivity.class);
						startActivityForResult(addIntent, ADD_REQUEST);
						return true;
					}
					// DELETE delete the currently selected book

					// CHECKOUT provide the UI for checking out
					if (item.getItemId() == R.id.checkout) {
						if (shoppingCart.size() < 0)
							return true;
						else {
							addIntent = new Intent(this, CheckoutActivity.class);
							startActivityForResult(addIntent, CHECKOUT_REQUEST);
							return true;
						}
					}

					return false;
				}

				@Override
				protected void onActivityResult(int requestCode, int resultCode,
												Intent intent) {
					super.onActivityResult(requestCode, resultCode, intent);
					// TODO Handle results from the Search and Checkout activities.
					// SEARCH: add the book that is returned to the shopping cart.
					if (requestCode == ADD_REQUEST) {
						if (resultCode == RESULT_OK) {
							Book b = intent.getExtras().getParcelable(AddBookActivity.BOOK_RESULT_KEY);
							shoppingCart.add(b);

						}
					} else if (requestCode == CHECKOUT_REQUEST) {
						if (resultCode == RESULT_OK) {

							shoppingCart.clear();
						} else if (requestCode == RESULT_CANCELED) {

						}
					}
					// Use SEARCH_REQUEST and CHECKOUT_REQUEST codes to distinguish the cases.

					// SEARCH: add the book that is returned to the shopping cart.

					// CHECKOUT: empty the shopping cart.

				}

				@Override
				public void onSaveInstanceState(Bundle savedInstanceState) {
					// TODO save the shopping cart contents (which should be a list of parcelables).
					savedInstanceState.putParcelableArrayList(cart, shoppingCart);
				}


				private void onClickDeleteButton() {

					SparseBooleanArray checked = listView.getCheckedItemPositions();
					Book[] books = new Book[checked.size()];
					for (int i = 0; i < checked.size(); i++) {
						if (checked.valueAt(i)) {
							Book theSelectedBook = (Book) listView.getItemAtPosition(checked.keyAt(i));
							books[i] = theSelectedBook;
							booksAdapter.remove(theSelectedBook);
							booksAdapter.notifyDataSetChanged();
						}
					}
					for (Book b : books) {
						shoppingCart.remove(b);
					}
					booksAdapter.notifyDataSetChanged();
				}
			}